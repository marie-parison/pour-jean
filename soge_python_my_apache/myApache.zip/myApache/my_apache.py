from core import core

core.start()